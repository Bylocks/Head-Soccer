--
--	Jackson Munsell
--	07/26/18
--	init.lua
--
--	Network init script
--

-- boot
require(game:GetService('ReplicatedStorage').src.boot)()

-- Module
local Network = {}

-- Init
function Network.Init(self)
end

-- return module
return Network
